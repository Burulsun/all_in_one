

import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableBooleanValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Person;
import model.SampleData;

import java.awt.*;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;


public class PersonUIController implements Initializable {



    ObservableList<String>genderList = FXCollections.observableArrayList("Male", "Female", "Other");

//    @FXML    private TextField firstnameTextField;
//    @FXML    private TextField lastnameTextField;
//    @FXML    private TextArea notesTextArea;
    @FXML    private Button removeButton;
    @FXML    private Button createButton;
    @FXML    private Button updateButton;
    @FXML    private ListView<Person> listView;
//    @FXML    private ChoiceBox genderChoiceBox;
//    @FXML    private DatePicker dp;
//    @FXML    private TextField dateFild;
    @FXML    private MenuItem exitMenuId;

    @FXML
    private Button addButton;

    @FXML
    private AnchorPane mainAnchor;

    private GraphicsContext graphicsContext;
    @FXML
    private Circle circle;





    private final ObservableList<Person> personList = FXCollections.observableArrayList(Person.extractor);
    // Observable objects returned by extractor (applied to each list element) are listened for changes and
    // transformed into "update" change of ListChangeListener.

    private Person selectedPerson;
    private final BooleanProperty modifiedProperty = new SimpleBooleanProperty(false);
    private ChangeListener<Person> personChangeListener;
    MenuItem menuName;
    MenuItem menuLast;
    MenuItem menuNotes;
    MenuItem menuBirthDate;
    MenuItem menuGender;
    ContextMenu cont;
    Scene scene1, scene2;
    Stage window;
    Button addBut;
    Label nameLabel;
    Label lastLabel;
    Label noteLabel;
    Label dateLabel;
    Label genderLabel;

    TextField nameField;
    TextField lastField;
    TextField noteField;
    DatePicker datePicker;
    ChoiceBox genderField;






    @Override
    public void initialize(URL url, ResourceBundle rb) {
        genderField = new ChoiceBox();
        genderField.setValue("Other");
        genderField.setItems(genderList);



        //String data = listView.getSelectionModel().getSelectedItem();


        // Disable the Remove/Edit buttons if nothing is selected in the ListView control


        removeButton.disableProperty().bind(listView.getSelectionModel().selectedItemProperty().isNull());
//        addBut.disableProperty().bind(
//                (modifiedProperty.not())
//                .or(firstnameTextField.textProperty().isEmpty()
//                        .or(lastnameTextField.textProperty().isEmpty()
//                                .or(genderChoiceBox.getSelectionModel().selectedItemProperty().isEqualTo("Other")))));
//
//        updateButton.disableProperty().bind(listView.getSelectionModel().selectedItemProperty().isNull()
//                .or(modifiedProperty.not())
//                .or(firstnameTextField.textProperty().isEmpty())
//                .or(lastnameTextField.textProperty().isEmpty())
//                .or(notesTextArea.textProperty().isEmpty())
//                        .or(genderChoiceBox.getSelectionModel().selectedItemProperty().isEqualTo("Other"))
//
//                        .or(genderChoiceBox.getSelectionModel().selectedItemProperty().isNull()));
//









        //add-> if dp and choicebox are empty disable createButton
//        createButton.disableProperty().bind((firstnameTextField.textProperty().isEmpty().and(lastnameTextField.textProperty().isEmpty()).
//                and()));




        SampleData.fillSampleData(personList);

        // Use a sorted list; sort by lastname; then by firstname
        SortedList<Person> sortedList = new SortedList<>(personList);

        // sort by lastname first, then by firstname; ignore notes
        sortedList.setComparator((p1, p2) -> {
            int result = p1.getLastname().compareToIgnoreCase(p2.getLastname());
            if (result == 0) {
                result = p1.getFirstname().compareToIgnoreCase(p2.getFirstname());
            }
            return result;
        });

        listView.setItems(sortedList);


        listView.getSelectionModel().selectedItemProperty().addListener(personChangeListener = (observable, oldValue, newValue) -> {
            System.out.println("Selected item: " + newValue);
            // newValue can be null if nothing is selected
            selectedPerson = newValue;


            // Boolean property modifiedProperty tracks whether the user has changed any of the
            //three text controls in the form. We reset this flag after each ListView selection and use
            //this property in a bind expression to control the Update button’s disable property.
            modifiedProperty.set(false);

            if (newValue != null) {
                // Populate controls with selected Person
//                firstnameTextField.setText(selectedPerson.getFirstname());
//                lastnameTextField.setText(selectedPerson.getLastname());
//                notesTextArea.setText(selectedPerson.getNotes());
//                genderChoiceBox.setValue(selectedPerson.getGender());
//                dp.setValue(selectedPerson.getDate());
                //imageShow.setImage(new Image(selectedPerson.getImagePath()));
                circle.setStroke(Color.SEAGREEN);
                Image im = new Image(selectedPerson.getImagePath(),false);
                circle.setFill(new ImagePattern(im));







                //dp.setValue(LocalDate.parse(selectedPerson.getDate()));
            }
//            else {
//                firstnameTextField.setText("");
//                lastnameTextField.setText("");
//                notesTextArea.setText("");
//
//
//                genderChoiceBox.setValue("");
//
//
//            }
        });







        mainAnchor.setOnContextMenuRequested(new EventHandler<ContextMenuEvent>() {
            @Override
            public void handle(ContextMenuEvent contextMenuEvent) {
                cont = new ContextMenu();
                if(cont != null){
                    cont.hide();
                }

                    menuName = new MenuItem("Name: "+ listView.getSelectionModel().getSelectedItem().getFirstname());
                    menuLast = new MenuItem("Last Name: " + listView.getSelectionModel().getSelectedItem().getLastname());
                    menuNotes = new MenuItem("Notes: "+listView.getSelectionModel().getSelectedItem().getNotes());
                    menuBirthDate = new MenuItem("Birth Date: "+ listView.getSelectionModel().getSelectedItem().getDate().toString() );
                    menuGender = new MenuItem("Gender: "+listView.getSelectionModel().getSelectedItem().getGender());
                    cont.getItems().addAll(menuName, menuLast,menuNotes, menuBirthDate, menuGender);
                    cont.show(mainAnchor, contextMenuEvent.getScreenX(), contextMenuEvent.getScreenX());


            }
        });

    }

    @FXML
    void CloseApp(ActionEvent event) {
        Platform.exit();
        System.exit(0);
        exitMenuId.setOnAction(e -> Platform.exit());
        exitMenuId.setAccelerator(new KeyCodeCombination(KeyCode.X, KeyCombination.SHORTCUT_DOWN));


    }
    @FXML
    void aboutPopUp(ActionEvent event) {

        Stage popUp = new Stage();
        popUp.initModality(Modality.APPLICATION_MODAL);
        popUp.setTitle("About Developer");
        TextArea textArea = new TextArea( "Date of App Creation:\t\t06.03.2021\nSoftware Developer Name:\tBurulsun\n" +
                "Software Developer Surname:\tTaalaibekova\n" +
                "Email:\t\t\t\t\tburulsun.taalaibekova_2021@ucentralasia.org\n" +
                "Contact Mobile Number:\t\t+996703979893\n");
        textArea.setEditable(false);
        textArea.setWrapText(true);
        textArea.setMaxWidth(Double.MAX_VALUE);
        textArea.setMaxHeight(Double.MAX_VALUE);
        VBox vBox = new VBox(15);
        vBox.getChildren().addAll(textArea);
        vBox.setAlignment(Pos.CENTER);
        popUp.setScene(new Scene(vBox));
        popUp.showAndWait();






    }


    @FXML
    void addButtonAction(ActionEvent event) {
        System.out.println("Create");
        Person person = new Person(nameField.getText(), lastField.getText(), noteField.getText(), datePicker.getValue(), genderField.getValue().toString());
        personList.add(person);


        // and select it
        listView.getSelectionModel().select(person);



    }



    @FXML
    private void handleKeyAction(KeyEvent keyEvent) {
        modifiedProperty.set(true);
    }

    @FXML
    private void createButtonAction(ActionEvent actionEvent) {

        Stage popUp = new Stage();
        popUp.initModality(Modality.APPLICATION_MODAL);
        popUp.setTitle("New Form");

        VBox vBox = new VBox();



        nameLabel = new Label("First Name");
        lastLabel = new Label("Last Name");
        noteLabel = new Label("Notes");
        dateLabel = new Label("BirthDate");
        genderLabel = new Label("Gender");



        nameField = new TextField();
        lastField = new TextField();
        noteField = new TextField();
        datePicker = new DatePicker();
       // genderField = new ChoiceBox();
        addBut = new Button("Add");
        addBut.setPadding(new Insets(10,10,10,10));

//        GridPane.setConstraints(nameField, 0,0);
//        GridPane.setConstraints(lastField, 0,1);
//        GridPane.setConstraints(noteField, 0,2);
//        GridPane.setConstraints(datePicker, 0,3);
//        GridPane.setConstraints(genderChoice, 0,4);




        vBox.getChildren().setAll(nameLabel, nameField, lastLabel, lastField, noteLabel, noteField, dateLabel, datePicker, genderLabel, genderField, addBut);
        vBox.setMinHeight(300);
        vBox.setMinWidth(300);






        addBut.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {


                Person person = new Person(nameField.getText(), lastField.getText(), noteField.getText(), datePicker.getValue(), genderField.getValue().toString());
                personList.add(person);
            }

            }


                );

        vBox.setAlignment(Pos.CENTER);
        popUp.setScene(new Scene(vBox));
        popUp.showAndWait();

    }



    @FXML
    private void removeButtonAction(ActionEvent actionEvent) {
        System.out.println("Remove " + selectedPerson);
        personList.remove(selectedPerson);
    }

    @FXML
    private void updateButtonAction(ActionEvent actionEvent) {
        System.out.println("Update " + selectedPerson);
        Person p = listView.getSelectionModel().getSelectedItem();
        listView.getSelectionModel().selectedItemProperty().removeListener(personChangeListener);
        p.setFirstname(nameField.getText());
        p.setLastname(lastField.getText());
        p.setNotes(noteField.getText());
        p.setDate(datePicker.getValue());
        p.setGender((String) genderField.getValue());


        listView.getSelectionModel().selectedItemProperty().addListener(personChangeListener);
        modifiedProperty.set(false);
    }


}
