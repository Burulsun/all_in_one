package threeDAnimation;

import javafx.scene.Parent;

public interface AnimatedShape {
    void animate(Parent parent);
}