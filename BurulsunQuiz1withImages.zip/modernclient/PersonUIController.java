

import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableBooleanValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import model.Person;
import model.SampleData;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class PersonUIController implements Initializable {

    ObservableList<String>genderList = FXCollections.observableArrayList("Male", "Female", "Other");

    @FXML    private TextField firstnameTextField;
    @FXML    private TextField lastnameTextField;
    @FXML    private TextArea notesTextArea;
    @FXML    private Button removeButton;
    @FXML    private Button createButton;
    @FXML    private Button updateButton;
    @FXML    private ListView<Person> listView;
    @FXML    private ChoiceBox genderChoiceBox;
    @FXML    private DatePicker dp;
    @FXML    private TextField dateFild;
    @FXML    private MenuItem exitMenuId;
    @FXML
    private ImageView imageShow;


    private final ObservableList<Person> personList = FXCollections.observableArrayList(Person.extractor);
    // Observable objects returned by extractor (applied to each list element) are listened for changes and
    // transformed into "update" change of ListChangeListener.

    private Person selectedPerson;
    private final BooleanProperty modifiedProperty = new SimpleBooleanProperty(false);
    private ChangeListener<Person> personChangeListener;



    @Override
    public void initialize(URL url, ResourceBundle rb) {






        // Disable the Remove/Edit buttons if nothing is selected in the ListView control
        removeButton.disableProperty().bind(listView.getSelectionModel().selectedItemProperty().isNull());

        updateButton.disableProperty().bind(listView.getSelectionModel().selectedItemProperty().isNull()
                .or(modifiedProperty.not())
                .or(firstnameTextField.textProperty().isEmpty()
                        .or(lastnameTextField.textProperty().isEmpty()
                        .or(genderChoiceBox.getSelectionModel().selectedItemProperty().isEqualTo("Other")))));
//.or(dateFild.getText().isEmpty())





        //add-> if dp and choicebox are empty disable createButton
        createButton.disableProperty().bind(listView.getSelectionModel().selectedItemProperty().isNotNull()
                .or(firstnameTextField.textProperty().isEmpty().or(lastnameTextField.textProperty().isEmpty())));




        SampleData.fillSampleData(personList);

        // Use a sorted list; sort by lastname; then by firstname
        SortedList<Person> sortedList = new SortedList<>(personList);

        // sort by lastname first, then by firstname; ignore notes
        sortedList.setComparator((p1, p2) -> {
            int result = p1.getLastname().compareToIgnoreCase(p2.getLastname());
            if (result == 0) {
                result = p1.getFirstname().compareToIgnoreCase(p2.getFirstname());
            }
            return result;
        });

        listView.setItems(sortedList);

        listView.getSelectionModel().selectedItemProperty().addListener(personChangeListener = (observable, oldValue, newValue) -> {
            System.out.println("Selected item: " + newValue);
            // newValue can be null if nothing is selected
            selectedPerson = newValue;

            // Boolean property modifiedProperty tracks whether the user has changed any of the
            //three text controls in the form. We reset this flag after each ListView selection and use
            //this property in a bind expression to control the Update button’s disable property.
            modifiedProperty.set(false);

            if (newValue != null) {
                // Populate controls with selected Person
                firstnameTextField.setText(selectedPerson.getFirstname());
                lastnameTextField.setText(selectedPerson.getLastname());
                notesTextArea.setText(selectedPerson.getNotes());
                genderChoiceBox.setValue(selectedPerson.getGender());
                dp.setValue(selectedPerson.getDate());
                imageShow.setImage(new Image(selectedPerson.getImagePath()));

                //dp.setValue();

                //dp.setValue(LocalDate.parse(selectedPerson.getDate()));
            } else {
                firstnameTextField.setText("");
                lastnameTextField.setText("");
                genderChoiceBox.setValue("");
                dateFild.setText("");
            }
        });

        // Pre-select the first item
        //listView.getSelectionModel().selectFirst();



        genderChoiceBox.setValue("Other");
        genderChoiceBox.setItems(genderList);

    }

    @FXML
    void CloseApp(ActionEvent event) {
//        Platform.exit();
//        System.exit(0);
        exitMenuId.setOnAction(e -> Platform.exit());
        exitMenuId.setAccelerator(new KeyCodeCombination(KeyCode.X, KeyCombination.SHORTCUT_DOWN));


    }
    @FXML
    void aboutPopUp(ActionEvent event) {

        Alert aboutSoftware = new Alert(Alert.AlertType.INFORMATION, "About Software");
        aboutSoftware.setTitle("About Software");
        aboutSoftware.setHeaderText("You have opened an \"About\" section");
        aboutSoftware.setContentText("Find full information here");

        Label label = new Label("Click to see:");

        TextArea textArea = new TextArea( "Date of App Creation:\t\t06.03.2021\nSoftware Developer Name:\tBurulsun\n" +
                "Software Developer Surname:\tTaalaibekova\n" +
                "Email:\t\t\t\t\tburulsun.taalaibekova_2021@ucentralasia.org\n" +
                "Contact Mobile Number:\t\t+996703979893\n");
        textArea.setEditable(false);
        textArea.setWrapText(true);

        textArea.setMaxWidth(Double.MAX_VALUE);
        textArea.setMaxHeight(Double.MAX_VALUE);

        GridPane.setVgrow(textArea, Priority.ALWAYS);
        GridPane.setHgrow(textArea, Priority.ALWAYS);

        GridPane content = new GridPane();
        content.setMaxWidth(Double.MAX_VALUE);
        content.add(label, 0,0);
        content.add(textArea,0,0);


        aboutSoftware.getDialogPane().setExpandableContent(content);

        aboutSoftware.showAndWait();


    }

    @FXML
    private void handleKeyAction(KeyEvent keyEvent) {
        modifiedProperty.set(true);
    }

    @FXML
    private void createButtonAction(ActionEvent actionEvent) {
        System.out.println("Create");
        Person person = new Person(firstnameTextField.getText(), lastnameTextField.getText(), notesTextArea.getText(), dp.getValue(), genderChoiceBox.getValue().toString());
        personList.add(person);
        // and select it
        listView.getSelectionModel().select(person);
    }

    @FXML
    private void removeButtonAction(ActionEvent actionEvent) {
        System.out.println("Remove " + selectedPerson);
        personList.remove(selectedPerson);
    }

    @FXML
    private void updateButtonAction(ActionEvent actionEvent) {
        System.out.println("Update " + selectedPerson);
        Person p = listView.getSelectionModel().getSelectedItem();
        listView.getSelectionModel().selectedItemProperty().removeListener(personChangeListener);
        p.setFirstname(firstnameTextField.getText());
        p.setLastname(lastnameTextField.getText());
        p.setNotes(notesTextArea.getText());
        p.setDate(dp.getValue());
        p.setGender((String) genderChoiceBox.getValue());


        listView.getSelectionModel().selectedItemProperty().addListener(personChangeListener);
        modifiedProperty.set(false);
    }

}
